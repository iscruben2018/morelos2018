<?php
echo "<script> window.location='../../../inicio.php';</script>"
?>